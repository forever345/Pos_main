/*****************************************************************//**
 * @file   Init_Loader.cpp
 * @brief  Plik zawierajacy definicje funkcji load_init_file_and_extract_variables sluzacej do odczytu zawartosci pliku init
 *
 * @author Aleksander Flont
 * @date   June 2024
 *********************************************************************/

#include "Image_processing.h"
extern map<string, string> init_variables;

/**
 * @brief Laduje plik init i ekstrahuje sciezke do folderu z obrazami oraz inne zmienne konfiguracyjne.
 *
 * Ta funkcja otwiera plik init o podanej sciezce, czyta go linia po linii i dzieli kazda linie na slowo kluczowe i wartosc.
 * Slowo kluczowe i wartosc sa dodawane do mapy init_variables. Jesli plik nie istnieje lub sciezka do folderu z obrazami
 * nie jest prawidlowa, funkcja zglasza wyjatek.
 *
 * @param init_file_path Sciezka do pliku init.
 * @param init_variables Mapa do przechowywania zmiennych init. Klucze sa slowami kluczowymi z pliku init, a wartosci sa wartosciami przypisanymi do tych slow kluczowych.
 * @throws runtime_error Jesli plik init nie istnieje lub sciezka do folderu z obrazami nie jest prawidlowa.
 */
void load_init_file_and_extract_variables(const string& init_file_path, map<string, string>& init_variables) {
    ifstream file(init_file_path);
    if (!file) {
        throw runtime_error("Nie mozna otworzyc pliku init");
    }

    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        string key;
        string value;
        if (iss >> key >> value) {
            init_variables[key] = value;
        }
    }

    auto it = init_variables.find("source_folder_path");
    if (it == init_variables.end() || !filesystem::exists(it->second) || !filesystem::is_directory(it->second)) {
        throw std::runtime_error("Scieżka " + it->second + " nie istnieje lub nie jest katalogiem");
    }
    it = init_variables.find("destination_folder_path");
    if (it == init_variables.end() || !filesystem::exists(it->second) || !filesystem::is_directory(it->second)) {
        throw runtime_error("Scieżka " + it->second + " nie istnieje lub nie jest katalogiem");
    }
}
