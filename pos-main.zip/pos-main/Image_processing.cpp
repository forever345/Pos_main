/*****************************************************************//**
 * @file   Image_processing.cpp
 * @brief  Program realizujacy przetwarzanie obrazow - detekcje krawedzi
 *
 * @author Hubert Aleksiuk, Oskar Bogucki, Aleksander Flont, Piotr Halman
 * @date   June 2024
 *********************************************************************/

#include <iostream>
#include "Image_processing.h"
#include <thread>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

map<string, string> init_variables;

int main()
{
    string source_folder_path, destination_folder_path;
    int square_size, margin, low_treshold, kernel_size, filter_size, t_ratio;

    // ZALADOWANIE PLIKU INIT ***************************************************************
    try {
        load_init_file_and_extract_variables("init.ini", init_variables);
        //wypisanie wszystkich zmiennych z pliku init do konsoli 
        for (const auto& [key, value] : init_variables) {
            cout << key << " = " << value << endl;
        }
        //konwersja string do path
        source_folder_path = init_variables["source_folder_path"];
        destination_folder_path = init_variables["destination_folder_path"];
        //konwersja liczb zapisanych w string do int
        square_size = stoi(init_variables["square_size"]);
        margin = stoi(init_variables["margin"]);
        low_treshold = stoi(init_variables["low_treshold"]);
        t_ratio = stoi(init_variables["t_ratio"]);
        kernel_size = stoi(init_variables["kernel_size"]);
        filter_size = stoi(init_variables["filter_size"]);
    }
    catch (const std::exception& e) {
        cerr << "Wystapil blad: " << e.what() << endl;
    }
    // **************************************************************************************

    
    // ODCZYT OBRAZOW Z PLIKU ***************************************************************
    cout << "Rozpoczecie odczytu obrazow z pliku \n\r";
    vector<Mat> source_images;
    mutex mtx_load;
    loading_images(source_folder_path, &source_images, 60, ref(mtx_load));
    cout << "Zakonczenie odczytu obrazow z pliku \n\r";
    // **************************************************************************************


    // DETEKCJA KRAWEDZI ********************************************************************
    cout << "Rozpoczecie detekcji krawedzi \n\r";
    vector<thread> threadVector_detect;
    vector<Mat> result_images(source_images.size());
    for (int i = 0; i < source_images.size();i++) {
        threadVector_detect.emplace_back(DetectEdges, source_images[i], &result_images[i], low_treshold, t_ratio, kernel_size, filter_size);
    }
    // czekanie na zakonczenie watkow
    for (auto& t : threadVector_detect) {
        t.join();
    }
    cout << "Zakonczenie detekcji krawedzi \n\r";
    // **************************************************************************************


    // STWORZENIE MINIATUR OBRAZOW WEJSCIOWYCH **********************************************
    cout << "Rozpoczecie tworzenia miniatur obrazow wejsciowych \n\r";
    Mat* resized_source_images = new Mat[source_images.size()];
    vector<thread> threadVector_resize;
    for (int i = 0; i < source_images.size(); i++) {
        threadVector_resize.emplace_back(resize_to_square, source_images[i], &resized_source_images[i], square_size, margin);
    }
    cout << "Zakonczenie tworzenia miniatur obrazow wejsciowych \n\r";
    // **************************************************************************************

    
    // STWORZENIE MINIATUR OBRAZOW WYNIKOWYCH ***********************************************
    cout << "Rozpoczecie tworzenia miniatur obrazow wynikowych \n\r";
    Mat* resized_result_images = new Mat[source_images.size()];
    for (int i = 0; i < source_images.size(); i++) {
        threadVector_resize.emplace_back(resize_to_square, result_images[i], &resized_result_images[i], square_size, margin);
    }
    // czekanie na zakonczenie resizowania obrazow wejsciowych
    for (auto& t : threadVector_resize) {
        t.join();
    }
    cout << "Zakonczenie tworzenia miniatur obrazow wynikowych \n\r";
    // **************************************************************************************

    // STWORZENIE KOLAZY MINIATUR ***********************************************************
    cout << "Rozpoczecie tworzenia kolazy miniatur \n\r";
    Mat miniature_source;
    miniature_source = make_photo_matrix(resized_source_images, (int)source_images.size(), square_size + 2 * margin);
    Mat miniature_result;
    miniature_result = make_photo_matrix(resized_result_images, (int)result_images.size(), square_size + 2 * margin);
    cout << "Zakonczenie tworzenia kolazy miniatur \n\r";
    // **************************************************************************************

    delete[] resized_result_images;
    delete[] resized_source_images;

    // ZAPIS OBRAZOW ************************************************************************
    cout << "Rozpoczecie zapisu obrazow \n\r";
    mutex mtx_save;
    vector<thread> threadVector_saving;
    for (int i = 0; i < source_images.size(); i++) {
        threadVector_saving.emplace_back(saving_image, destination_folder_path, result_images[i], "image_", i, ref(mtx_save));
    }
    for (auto& t : threadVector_saving) {
        t.join();
    }
    saving_image(destination_folder_path, miniature_source, "miniature_source_", 0, ref(mtx_save));
    saving_image(destination_folder_path, miniature_result, "miniature_result_", 0, ref(mtx_save));
    cout << "Zakonczenie zapisu obrazow \n\r";
    // **************************************************************************************

    return 0;
}
