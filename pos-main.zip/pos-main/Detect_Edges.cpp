/*****************************************************************//**
 * @file   Detect_Edges.cpp
 * @brief  Plik zawierajacy funkcje DetectEdges sluzaca do wykrywania krawedzi w obrazie.
 * 
 * @author Hubert Aleksiuk
 * @date   June 2024
 *********************************************************************/

#include "Image_processing.h"

using namespace cv;

/**
 * @brief Funkcja wykrywajaca krawedzie
 *
 * Funkcja realizujaca wykrywanie krawedzi na 1 obrazie wejsciowym i zapisujaca wynik w miejscu podanego jako
 * argument wejsciowy wskaznika.
 * 
 * @param src - macierz z obrazem wejsciowym
 * @param res - wskaznik na macierz, do ktorej ma trafic plik wyjsciowy
 * @param treshold - dolny prog wykrywania krawedzi
 * @param r - stosunek miedzy dolnym a gornym progiem wykrywania krawedzi
 * @param k_size - rozmiar filtru Canny-ego (filtr bedzie mial wymiary k_size x k_size)
 * @param f_size - rozmiar filtru wygladzajacego (filtr bedzie mial wymiary f_size x f_size)
 */
void DetectEdges(Mat src, Mat* res, int treshold, int r, int k_size, int f_size) {

    // utworzenie pomocniczych zmiennych
    Mat dst, src_gray, detected_edges; 
    dst.create(src.size(), src.type());     // utworzenie dst o takim samym rozmiarze i typie, co src

    // transformacja obrazu wejsciowego do monochromatycznego
    cvtColor(src, src_gray, COLOR_BGR2GRAY);

    blur(src_gray, detected_edges, Size(f_size, f_size));     // wykorzystanie filtru "blur"
    Canny(detected_edges, detected_edges, treshold, treshold * r, k_size);   // wykorzystanie filtru Canny-ego
    // wypelnienie zmiennej obrazu docelowego zerami (czyli utworzenie czarnego obrazu)
    dst = Scalar::all(0);

    // skopiowanie do dst tylko tych czeeci src, na ktorych zostaly wykryte krawedzie
    src.copyTo(dst, detected_edges);

    // zapisanie wyniku w miejsce wskazywane przez wskaznik res
    *res = dst;
}
