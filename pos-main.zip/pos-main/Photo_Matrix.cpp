/*****************************************************************//**
 * @file   Photo_Matrix.cpp
 * @brief  Plik zawierajacy definicje funkcji make_photo_matrix oraz resize_to_square sluzace do tworzenia kolazu z obrazow
 *
 * @author Oskar Bogucki
 * @date   June 2024
 *********************************************************************/

#include "Image_processing.h"

using namespace cv;

/**
 * @brief Tworzy matryce zdjec z podanego zestawu obrazow, ukladajac je w siatke.
 *
 * Ta funkcja przyjmuje zestaw obrazow o tym samym wymiarze i ukladac je w matrycy (siatce).
 * Obrazy sa umieszczane na bialym tle o odpowiednich wymiarach, aby utworzyc kompletna matryce zdjec.
 *
 * @param images Tablica obrazow (Mat) do ulozenia w matryce.
 * @param i Liczba obrazow w tablicy.
 * @param photo_size Rozmiar pojedynczego zdjecia w matrycy.
 *
 * @return Mat zawierajacy matryce zdjec.
 *
 * @details Funkcja oblicza liczbe wierszy i kolumn potrzebnych do utworzenia matrycy z podanej liczby obrazow.
 * Nastepnie tworzy pusty obiekt Mat o wymiarach wystarczajacych do pomieszczenia wszystkich obrazow. Obrazy sa
 * kopiowane do odpowiednich miejsc w matrycy w petli, az wszystkie obrazy zostana umieszczone.
 *
 * Przykladowe uzycie:
 * @code
 * Mat images[4] = {imread("img1.jpg"), imread("img2.jpg"), imread("img3.jpg"), imread("img4.jpg")};
 * Mat photo_matrix = make_photo_matrix(images, 4, 100);
 * imshow("Photo Matrix", photo_matrix);
 * waitKey(0);
 * @endcode
 */
Mat make_photo_matrix(Mat images[], int i, int photo_size) {
    int number_of_rows = (int)ceil(sqrt(i));
    int number_of_columns = (int)ceil(i / (float)number_of_rows);
    Mat square_container(photo_size * number_of_rows, photo_size * number_of_columns, CV_8UC3, Scalar(255, 255, 255));
    int image_cntr = 0;
    for (int j = 0; j < number_of_rows; j++) {
        for (int k = 0; k < number_of_columns; k++) {
            images[image_cntr].copyTo(square_container(Rect(k * photo_size, j * photo_size, photo_size, photo_size)));
            image_cntr++;
            if (image_cntr == i) break;
        }
        if (image_cntr == i) break;
    }
    return square_container;
}

/**
 * @brief Zmienia rozmiar obrazu wejsciowego, aby pasowal do kwadratu o okreslonym rozmiarze z opcjonalnymi marginesami, zachowujac proporcje.
 *
 * Ta funkcja przyjmuje obraz wejsciowy i zmienia jego rozmiar tak, aby pasowal do kwadratu o okreslonym rozmiarze. Przeskalowany obraz
 * jest nastepnie wysrodkowany w wiekszym kwadracie z opcjonalnymi marginesami, wypelnionym okreslonym kolorem (domyslnie bialym).
 *
 * @param image Obraz wejsciowy, ktory ma zostac przeskalowany.
 * @param result Wskaznik na wynikowy obraz (przeskalowany i wysrodkowany w kwadracie).
 * @param square_size Rozmiar kwadratu, do ktorego ma pasowac przeskalowany obraz.
 * @param margin Opcjonalny margines do dodania wokol przeskalowanego obrazu w kwadracie.
 *
 * @details Funkcja najpierw oblicza wspolczynnik proporcji obrazu wejsciowego. Na podstawie wspolczynnika proporcji zmienia rozmiar obrazu
 * poprzez dostosowanie szerokosci lub wysokosci, aby pasowal do kwadratu. Przeskalowany obraz jest nastepnie kopiowany do srodka nowego kwadratowego
 * obiektu Mat, ktory obejmuje okreslone marginesy.
 *
 * Przykladowe uzycie:
 * @code
 * Mat input_image = imread("path_to_image.jpg");
 * Mat output_image;
 * resize_to_square(input_image, &output_image, 300, 10);
 * imshow("Resized Image", output_image);
 * waitKey(0);
 * @endcode
 */

void resize_to_square(Mat image, Mat* result, int square_size, int margin) {
    float ratio = (float)image.rows / image.cols; // stosunek wysokosci do szerokosci obrazu
    int new_height = square_size;
    int new_length = square_size;
    Mat resized_image;
    // stworzenie pustego kwadratu do ktorego zapisany bedzie przeskalowany obraz
    Mat square_container(square_size + 2 * margin, square_size + 2 * margin, CV_8UC3, Scalar(255, 255, 255));
    if (ratio < 1) { // wejsciowy obraz jest szerszy niz wyzszy
        new_length = (int)(square_size * ratio);
        resize(image, resized_image, Size(new_height, new_length), INTER_LINEAR);
        resized_image.copyTo(square_container(Rect(margin, square_size / 2 - resized_image.rows / 2 + margin, resized_image.cols, resized_image.rows)));
    }
    else if (ratio > 1) { // wejsciowy obraz jest wyzszy niz szerszy
        new_height = (int)(square_size / ratio);
        resize(image, resized_image, Size(new_height, new_length), INTER_LINEAR);
        resized_image.copyTo(square_container(Rect(square_size / 2 - resized_image.cols / 2 + margin, margin, resized_image.cols, resized_image.rows)));
    }
    else { // wejsciowy obraz jest kwadratowy
        resize(image, resized_image, Size(new_height, new_length), INTER_LINEAR);
        resized_image.copyTo(square_container(Rect(margin, margin, resized_image.cols, resized_image.rows)));
    }
    resized_image = square_container;
    *result = resized_image;
}
