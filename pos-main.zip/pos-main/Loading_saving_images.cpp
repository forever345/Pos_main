/*****************************************************************//**
 * @file   Loading_saving_images.cpp
 * @brief  Plik zawierajacy definicje funkcji loading_images, load_image oraz saving_images sluzace do odczytywania i zapisywania obrazow
 *
 * @author Piotr Halman
 * @date   June 2024
 *********************************************************************/

#include "Image_processing.h"

using namespace cv;
using namespace std;

extern map<string,string> init_variables;

/**
 * @brief Laduje obrazy z podanej sciezki przy uzyciu wielowatkowosci i zapisuje je w wektorze Mat.
 *
 * Ta funkcja przeszukuje podana sciezke zrodlowa w poszukiwaniu obrazow, a nastepnie laduje je do wektora Mat przy uzyciu wielowatkowosci.
 * Kazdy watek laduje czesc obrazow, co przyspiesza caly proces.
 *
 * @param source_path Sciezka do folderu zawierajacego obrazy.
 * @param data Wskaznik na wektor Mat, do ktorego zostana zaladowane obrazy.
 * @param num_threads Liczba watkow uzywanych do ladowania obrazow.
 * @param mtx Referencja do mutexu uzywanego do synchronizacji dostepu do wektora danych.
 *
 * @details Funkcja uzywa cv::glob do znalezienia wszystkich plikow obrazow w podanej sciezce. Oblicza liczbe obrazow do zaladowania
 * przez kazdy watek i tworzy watki, ktore rownolegle laduja obrazy do wektora danych. Kazdy watek jest synchronizowany za pomoca mutexu
 * podczas zapisu obrazow do wspolnego wektora.
 *
 * Przykladowe uzycie:
 * @code
 * vector<Mat> images;
 * mutex mtx;
 * loading_images("path_to_images_folder", &images, 4, mtx);
 * for (const auto& img : images) {
 *     imshow("Loaded Image", img);
 *     waitKey(0);
 * }
 * @endcode
 */
void loading_images(String source_path, vector<Mat>* data, int num_threads, mutex& mtx) {
    vector<String> fn;
    glob(source_path, fn, false);

    size_t total_images = fn.size();
    size_t images_per_thread = total_images / num_threads;
    size_t remainder = total_images % num_threads;

    vector<thread> threads;

    size_t start = 0;
    for (int i = 0; i < num_threads; ++i) {
        size_t end = start + images_per_thread + (i < remainder ? 1 : 0); // Rozdziela reszte
        threads.emplace_back(load_image, std::ref(fn), data, start, end, ref(mtx));
        start = end;
    }

    // Laczenie watkow z glownym watkiem
    for (auto& t : threads) {
        t.join();
    }
}

/**
 * @brief Laduje czesc obrazow z listy plikow do wektora Mat z synchronizacja.
 *
 * Ta funkcja jest uzywana przez watki do ladowania czesci obrazow z listy plikow do wspolnego wektora Mat. Dostep do wektora jest
 * synchronizowany za pomoca mutexu.
 *
 * @param fn Referencja do listy plikow obrazow.
 * @param data Wskaznik na wektor Mat, do ktorego zostana zaladowane obrazy.
 * @param start Indeks poczatkowy zakresu obrazow do zaladowania przez watek.
 * @param end Indeks koncowy zakresu obrazow do zaladowania przez watek.
 * @param mtx Referencja do mutexu uzywanego do synchronizacji dostepu do wektora danych.
 */
void load_image(const vector<String>& fn, vector<Mat>* data, size_t start, size_t end, mutex& mtx) {
    for (size_t k = start; k < end; ++k) {
        Mat im = imread(fn[k]);
        if (im.empty()) continue;
        lock_guard<mutex> lock(mtx); // Zapewnienie bezpiecznego dostepu do wektora danych
        data->push_back(im);
    }
}

/**
 * @brief Zapisuje pojedynczy obraz do pliku w okreslonej sciezce z nadanym prefiksem i numerem, z uzyciem mutexu do synchronizacji.
 *
 * Ta funkcja zapisuje pojedynczy obraz Mat do pliku w podanej sciezce docelowej. Plik otrzymuje nazwe skladajaca sie z prefiksu i numeru obrazu.
 * Operacja zapisu jest synchronizowana za pomoca mutexu, aby zapewnic bezpieczny dostep w srodowiskach wielowatkowych.
 *
 * @param target_path Sciezka do folderu, w ktorym ma zostac zapisany obraz.
 * @param data Obraz (Mat) do zapisania.
 * @param prefix Prefiks uzywany w nazwie pliku zapisywanego obrazu.
 * @param number Numer obrazu dodawany do nazwy pliku.
 * @param mtx Referencja do mutexu uzywanego do synchronizacji operacji zapisu.
 *
 * @details Funkcja tworzy nazwe pliku na podstawie sciezki docelowej, prefiksu i numeru obrazu. Nastepnie zapisuje obraz do pliku uzywajac cv::imwrite.
 * Jesli zapis sie nie powiedzie, wypisuje komunikat o bledzie na standardowe wyjscie bledow (std::cerr) z uzyciem mutexu do synchronizacji.
 * Jesli zapis sie powiedzie, wypisuje komunikat na standardowe wyjscie (std::cout) z uzyciem mutexu do synchronizacji.
 *
 * Przykladowe uzycie:
 * @code
 * Mat image = imread("img.jpg");
 * mutex mtx;
 * saving_image("output_folder/", image, "image_", 1, mtx);
 * @endcode
 */
void saving_image(String target_path, Mat data, string prefix, int number, mutex& mtx) {
    // Tworzenie sciezki wyjsciowej dla kazdego obrazu
    string outputFileName = target_path + prefix + to_string(number) + ".png";
    // Zapisanie obrazu do pliku
    if (!imwrite(outputFileName, data)) {
        lock_guard<mutex> lock(mtx);
        cerr << "Error saving image: " << outputFileName << endl;
    }
    else {
        lock_guard<mutex> lock(mtx);
        cout << "Saved image: " << outputFileName << endl;
    }
}
