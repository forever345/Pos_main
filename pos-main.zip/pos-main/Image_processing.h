/*****************************************************************//**
 * @file   Detect_Edges.h
 * @brief  Plik naglowkowy zawierajacy wykorzystywane biblioteki opencv oraz deklaracje funkcji z poszczegolnych plikow 
 *
 * @author Hubert Aleksiuk, Oskar Bogucki, Aleksander Flont, Piotr Halman
 * @date   June 2024
 *********************************************************************/

#ifndef DETECT_EDGES
#define DETECT_EDGES

#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/core.hpp>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <filesystem>
#include <sstream>
#include <map>
#include <thread>

using namespace cv;
using namespace std;

// funkcja z Detect_Edges.cpp
void DetectEdges(Mat src, Mat* res, int treshold, int r, int k_size, int f_size);
// funkcja z Init_Loader.cpp
void load_init_file_and_extract_variables(const string& init_file_path, map<string, string>& init_variables);
// funkcje z Photo_Matrix.cpp
Mat make_photo_matrix(Mat images[], int i, int photo_size);
void resize_to_square(Mat image, Mat* result, int square_size, int margin);
// funkcje z Loading_saving_images.cpp
void loading_images(String source_path, vector<Mat>* data, int num_threads, mutex& mtx);
void load_image(const vector<String>& fn, vector<Mat>* data, size_t start, size_t end, mutex& data_mutex);
void saving_image(String target_path, Mat data, string prefix, int number, mutex& mtx);
#endif
